interface Navigator {
  xr: any;
}

declare module "*.png" {
  const value: any;
  export default value;
}

declare module "*.glb";
